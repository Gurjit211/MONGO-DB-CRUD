const express = require("express");
const { ObjectId } = require("mongodb");
const dotenv = require("dotenv");
const { connectDB } = require("./db-helper");

dotenv.config();

const app = express();
app.use(express.json());

let db;
connectDB().then((database) => {
    db = database;
});

const collectionName = process.env.COLLECTION_NAME;

// **Get all books from the books array**
app.get("/books", async (req, res) => {
    try {
        const result = await db.collection(collectionName).findOne({}, { projection: { books: 1, _id: 0 } });

        if (!result || !result.books) {
            return res.status(404).json({ message: "No books found" });
        }

        res.status(200).json(result.books);
    } catch (error) {
        res.status(500).json({ message: "Server error" });
    }
});

// **Get a book by bookname or authorname**
app.get("/books/search", async (req, res) => {
    try {
        const { bookname, authorname } = req.query;

        if (!bookname && !authorname) {
            return res.status(400).json({ message: "Provide either bookname or authorname" });
        }

        const query = {};
        if (bookname) query["books.bookname"] = bookname;
        if (authorname) query["books.authorname"] = authorname;

        const result = await db.collection(collectionName).findOne(query, { projection: { "books.$": 1 } });

        if (!result || !result.books || result.books.length === 0) {
            return res.status(404).json({ message: "Book not found" });
        }

        res.status(200).json(result.books[0]);
    } catch (error) {
        res.status(500).json({ message: "Server error" });
    }
});

// **Add a new book to the books array**
app.post("/books", async (req, res) => {
    try {
        const newBook = {
            _id: new ObjectId(),
            ...req.body
        };

        const result = await db.collection(collectionName).updateOne(
            {},
            { $push: { books: newBook } }
        );

        if (result.modifiedCount === 0) {
            return res.status(400).json({ message: "Book could not be added" });
        }

        res.status(201).json({ message: "Book added successfully", id: newBook._id });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// **Update a book by bookname or authorname**
app.put("/books/update", async (req, res) => {
    try {
        const { bookname, authorname } = req.query;
        const updateFields = req.body;

        if (!bookname && !authorname) {
            return res.status(400).json({ message: "Provide either bookname or authorname to update" });
        }

        const query = {};
        if (bookname) query["books.bookname"] = bookname;
        if (authorname) query["books.authorname"] = authorname;

        const updateQuery = {};
        for (const key in updateFields) {
            if (key !== "_id") {
                updateQuery[`books.$.${key}`] = updateFields[key];
            }
        }

        const result = await db.collection(collectionName).updateOne(query, { $set: updateQuery });

        if (result.matchedCount === 0) {
            return res.status(404).json({ message: "Book not found" });
        }

        res.status(200).json({ message: "Book updated successfully" });
    } catch (error) {
        res.status(500).json({ message: "Server error" });
    }
});

// **Delete a book by bookname or authorname**
app.delete("/books/delete", async (req, res) => {
    try {
        let { bookname, authorname } = req.query;

        if (!bookname && !authorname) {
            return res.status(400).json({ message: "Provide bookname or authorname to delete" });
        }

        let query = {};
        if (bookname) query["books.bookname"] = { $regex: `^${bookname.trim()}$`, $options: "i" };
        if (authorname) query["books.authorname"] = { $regex: `^${authorname.trim()}$`, $options: "i" };

        const result = await db.collection(collectionName).updateOne(
            {},
            { $pull: { books: query } }
        );

        if (result.modifiedCount === 0) {
            return res.status(404).json({ message: `Book with '${bookname || authorname}' not found` });
        }

        res.status(200).json({ message: `Book with '${bookname || authorname}' deleted successfully` });
    } catch (error) {
        res.status(500).json({ message: "Server error" });
    }
});


